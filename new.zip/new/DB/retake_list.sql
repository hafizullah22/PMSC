-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2025 at 11:09 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmsc`
--

-- --------------------------------------------------------

--
-- Table structure for table `retake_list`
--

CREATE TABLE `retake_list` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `student_list` text NOT NULL,
  `exam_year` varchar(256) NOT NULL,
  `status` int(2) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `retake_list`
--

INSERT INTO `retake_list` (`id`, `course_id`, `student_list`, `exam_year`, `status`) VALUES
(1, 1, 'M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015', 'July-2025', 1),
(7, 3, 'M230102014', 'July-2025', 1),
(8, 4, 'M230102014', 'July-2025', 1),
(10, 5, 'M230102014, M230102015, M230102015,', 'December-2025', 1),
(11, 6, 'M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015,M230201012, M230201014, M230201015', 'July-2026', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `retake_list`
--
ALTER TABLE `retake_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `retake_list`
--
ALTER TABLE `retake_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
